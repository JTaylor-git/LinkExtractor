import sys
input_data = sys.stdin.read()
print("You said:", input_data.upper())