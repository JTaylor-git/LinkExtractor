export interface PluginManifest {
  id: string;
  name: string;
  description: string;
  entry: string;
}